def modpow(base, exponent, modulus):
'''
Takes three inputs in order the base, the exponent and the modulus.
need to be numbers and computes something
'''
	base ** exponent % modulus