num = input ("Enter number :") 
print(num) 
name1 = input("Enter name : ") 
print(name1) 
  
# Printing type of input value 
print ("type of number", type(num)) 
print ("type of name", type(name1)) 
